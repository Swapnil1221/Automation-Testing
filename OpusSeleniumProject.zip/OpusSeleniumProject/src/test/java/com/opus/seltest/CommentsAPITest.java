
package com.opus.seltest;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.internal.BaseClassFinder;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CommentsAPITest extends BaseClassFinder {
	String Base_URI = "http://ec2-54-84-52-184.compute-1.amazonaws.com:3000/comments";
	
	// For testing GET API
	int get_id = 3;
	
	// For testing POST API
	String id = "opusid_";
	String postId = "opus_postId_";
	String email = "opusemail@gmail.com";
	String body = "Opus India";
	
	// For testing PUT API
	String put_id = "opusid_";
	String put_postId = "opus_postId_changed";
	String put_email = "opusemail@gmail.com";
	String put_body = "Opus India Changed";

	@Test
	public void getAPITest() {

		RestAssured.baseURI = Base_URI;

		RequestSpecification httpRequest = RestAssured.given();

		Response response = httpRequest.request(Method.GET, "/" + get_id);
		int statusCode = response.getStatusCode();
		System.out.println("comments GET Response statusCode " + statusCode);
		
		Assert.assertEquals(statusCode, 200);
		
		String responseBody = response.getBody().asString();
		System.out.println("comments GET Response Body is =>  " + responseBody);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void postAPITest() {

		RestAssured.baseURI = Base_URI;
		RequestSpecification request = RestAssured.given();
		JSONObject requestParams = new JSONObject();
		
		requestParams.put("id", this.id + Math.random()*9);
		requestParams.put("postId", this.postId + Math.random()*9); // Cast
		requestParams.put("email", this.email);
		requestParams.put("body", this.body);
		

		System.out.println("comments POST Json object created: " + requestParams.toString());
		request.header("Content-Type", "application/json");
		request.body(requestParams);
		
		// Make the POST API Call
		Response response = request.post(RestAssured.baseURI);
		int statusCode = response.getStatusCode();
		
		System.out.println("comments POST Response statusCode " + statusCode);
		System.out.println("comments POST Response" + response.asString());
		
		Assert.assertEquals(statusCode, 201);
		String email = response.jsonPath().get("email");
		Assert.assertEquals(email, this.email, "comments POST API Success");
	}

	@SuppressWarnings("unchecked")
	@Test
	public void putAPITest() {

		RestAssured.baseURI = Base_URI;
		RequestSpecification request = RestAssured.given();

		JSONObject requestParams = new JSONObject();
		requestParams.put("postId", this.put_postId); // Cast
		requestParams.put("email", this.put_email);
		requestParams.put("body", this.put_body);
		requestParams.put("id", this.put_id);

		System.out.println("comments Json object created in putAPITest: " + requestParams.toString());

		request.header("Content-Type", "application/json");

		request.body(requestParams.toJSONString());
		Response response = request.put(RestAssured.baseURI);

		int statusCode = response.getStatusCode();
		
		System.out.println("comments PUT Response statusCode " + statusCode);

		System.out.println("comments putAPITest response" + response.asString());
		
		//Assert.assertEquals(statusCode, 201, "PUT API Success");
		Assert.assertEquals(statusCode, 404, "comments PUT API Failure. Resource NOT found");
	}

}
