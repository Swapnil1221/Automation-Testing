
package com.opus.seltest;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.internal.BaseClassFinder;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UsersAPITest extends BaseClassFinder {
	String Base_URI = "http://ec2-54-84-52-184.compute-1.amazonaws.com:3000/users";
	
	// For testing GET API
	int get_id = 1;
	
	// For testing POST API
	String id = "opusid_";
	String username = "opus_user";
	String email = "opusemail@gmail.com";
	String address = "CommerZone IT Park, Pune";
	String phone = "9019232332";
	String website = "https://www.opusconsulting.com";
	
	// For testing PUT API
	String put_id = "opusid_";
	String put_username = "opus_user";
	String put_email = "opusemail@gmail.com";
	String put_address = "CommerZonet IT Park, Pune";
	String put_phone = "9019232332";
	String put_website = "https://www.opusconsulting.com";

	@Test
	public void getAPITest() {

		RestAssured.baseURI = Base_URI;

		RequestSpecification httpRequest = RestAssured.given();

		Response response = httpRequest.request(Method.GET, "/" + get_id);
		int statusCode = response.getStatusCode();
		System.out.println("users GET Response statusCode " + statusCode);
		
		Assert.assertEquals(statusCode, 200);
		
		String responseBody = response.getBody().asString();
		System.out.println("users GET Response Body is =>  " + responseBody);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void postAPITest() {

		RestAssured.baseURI = Base_URI;
		RequestSpecification request = RestAssured.given();
		JSONObject requestParams = new JSONObject();
		
		requestParams.put("id", this.id + Math.random()*9);
		requestParams.put("username", this.username + Math.random()*9); // Cast
		requestParams.put("email", this.email);
		requestParams.put("address", this.address);
		requestParams.put("phone", this.phone);
		requestParams.put("website", this.website);
		

		System.out.println("users POST Json object created: " + requestParams.toString());
		request.header("Content-Type", "application/json");
		request.body(requestParams);
		
		// Make the POST API Call
		Response response = request.post(RestAssured.baseURI);
		int statusCode = response.getStatusCode();
		
		System.out.println("users POST Response statusCode " + statusCode);
		System.out.println("users POST Response" + response.asString());
		
		Assert.assertEquals(statusCode, 201);
		String email = response.jsonPath().get("email");
		Assert.assertEquals(email, this.email, "users POST API Success");
	}

	@SuppressWarnings("unchecked")
	@Test
	public void putAPITest() {

		RestAssured.baseURI = Base_URI;
		RequestSpecification request = RestAssured.given();

		JSONObject requestParams = new JSONObject();
		requestParams.put("username", this.put_username); // Cast
		requestParams.put("email", this.put_email);
		requestParams.put("address", this.put_address);
		requestParams.put("phone", this.put_phone);
		requestParams.put("website", this.put_website);
		requestParams.put("id", this.put_id);

		System.out.println("users PUT Json object created in putAPITest: " + requestParams.toString());

		request.header("Content-Type", "application/json");

		request.body(requestParams.toJSONString());
		Response response = request.put(RestAssured.baseURI);

		int statusCode = response.getStatusCode();
		
		System.out.println("users PUT Response statusCode " + statusCode);

		System.out.println("users putAPITest response" + response.asString());
		
		//Assert.assertEquals(statusCode, 201, "PUT API Success");
		Assert.assertEquals(statusCode, 404, "users PUT API Failure. Resource NOT found");
	}

}
