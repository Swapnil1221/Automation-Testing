
package com.opus.seltest;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.internal.BaseClassFinder;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PostsAPITest extends BaseClassFinder {
	String Base_URI = "http://ec2-54-84-52-184.compute-1.amazonaws.com:3000/posts";
	
	// For testing GET API
	String get_id = "id_001";
	
	// For testing POST API
	String id = "opusid_";
	String userId = "opus_userid_";
	String title = "Opus Consulting";
	String body = "Opus Solution Private Limited";
	
	// For testing PUT API
	String put_id = "1981003";
	String put_userId = "change_1981003";
	String put_title = "change_Lord Of The Rings";
	String put_body = "Change Rock your body";

	@Test
	public void postGetAPITest() {

		RestAssured.baseURI = Base_URI;

		RequestSpecification httpRequest = RestAssured.given();

		Response response = httpRequest.request(Method.GET, "/" + get_id);
		int statusCode = response.getStatusCode();
		System.out.println("GET Response statusCode " + statusCode);
		
		Assert.assertEquals(statusCode, 200);
		
		String responseBody = response.getBody().asString();
		System.out.println("GET Response Body is =>  " + responseBody);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void postAPITest() {

		RestAssured.baseURI = Base_URI;
		RequestSpecification request = RestAssured.given();
		JSONObject requestParams = new JSONObject();
		
		requestParams.put("userId", this.userId + Math.random()*9); // Cast
		requestParams.put("title", this.title);
		requestParams.put("bogdy", this.body);
		requestParams.put("id", this.id + Math.random()*9);

		System.out.println("Json object created: " + requestParams.toString());
		request.header("Content-Type", "application/json");
		request.body(requestParams);
		
		// Make the POST API Call
		Response response = request.post(RestAssured.baseURI);
		int statusCode = response.getStatusCode();
		
		System.out.println("POST Response statusCode " + statusCode);
		System.out.println("POST Response" + response.asString());
		
		Assert.assertEquals(statusCode, 201);
		String title = response.jsonPath().get("title");
		Assert.assertEquals(title, this.title, "POST API Success");
	}

	@SuppressWarnings("unchecked")
	@Test
	public void putAPITest() {

		RestAssured.baseURI = Base_URI;
		RequestSpecification request = RestAssured.given();

		JSONObject requestParams = new JSONObject();
		requestParams.put("userId", this.put_userId); // Cast
		requestParams.put("title", this.put_title);
		requestParams.put("body", this.put_body);
		requestParams.put("id", this.put_id);

		System.out.println("Json object created in putAPITest: " + requestParams.toString());

		request.header("Content-Type", "application/json");

		request.body(requestParams.toJSONString());
		Response response = request.put(RestAssured.baseURI);

		int statusCode = response.getStatusCode();
		
		System.out.println("PUT Response statusCode " + statusCode);

		System.out.println("putAPITest response" + response.asString());
		
		//Assert.assertEquals(statusCode, 201, "PUT API Success");
		Assert.assertEquals(statusCode, 404, "PUT API Failure. Resource NOT found");
	}

}
