package com.mes.test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class testBase {
	Properties connectionProperty;
	Properties webElementsProperty;
	FileInputStream fis = null;
	WebDriver driver;

	protected void initFile() {
		if(connectionProperty==null){			
			try {
				connectionProperty = new Properties();
				fis = new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\java\\connection.properties");
				connectionProperty.load(fis);
				
				webElementsProperty = new Properties();
				fis = new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\java\\webElements.properties");
				webElementsProperty.load(fis);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	protected void openBrowser(String browserType) {
		String browserName = connectionProperty.getProperty("browser");
		if(browserName.equals("Chrome")){
			System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "\\src\\test\\java\\drivers\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		System.out.println("url is: "+connectionProperty.getProperty("url"));
		driver.get(connectionProperty.getProperty("url"));
	}
	protected void click(String ElementKey){
		getelement(ElementKey).click();
	}
	protected WebElement getelement(String ElementKey) {

		WebElement element = null;
		WebDriverWait wait = null;

		try {
			if (ElementKey.endsWith("_id")) {
				wait = new WebDriverWait(driver, 30);
				element = wait.until(ExpectedConditions.elementToBeClickable(By.id(webElementsProperty.getProperty(ElementKey))));
			} else if (ElementKey.endsWith("_xpath")) {
				wait = new WebDriverWait(driver, 30);
				element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(webElementsProperty.getProperty(ElementKey))));
			}
			else if (ElementKey.endsWith("_linkText")) {
				wait = new WebDriverWait(driver, 30);
				element = wait.until(ExpectedConditions.elementToBeClickable(By.linkText(webElementsProperty.getProperty(ElementKey))));
			}else if (ElementKey.endsWith("_name")) {
				wait = new WebDriverWait(driver, 30);
				element = wait.until(ExpectedConditions.elementToBeClickable(By.name(webElementsProperty.getProperty(ElementKey))));
			}
			else {
				Assert.fail("not able to locate element " + webElementsProperty.getProperty(ElementKey));
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return element;
	}
	protected String getText(String elementName){
		return driver.findElement(By.id(elementName)).getText();
	}
	protected void Close() {
		if(!(driver==null)) {
		driver.close();
		}
	}

	private void Quit() {
		if(!(driver==null)) {
			driver.quit();
		}
	}
	private WebDriver getDriver() {
		return driver;
	}
}
