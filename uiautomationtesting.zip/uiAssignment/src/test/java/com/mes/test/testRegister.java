/**********
 * 
 * @author Swapnil.Melshankare
 * Test case for retrieving records using filters.
 */
package com.mes.test;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class testRegister extends testBase {
	String pageTitle;
	String username = "Swapnil1221";
	String password = "test@123";
	String email = "Swapnil.melshankare@opusconsulting.com";

	@BeforeTest
	private void initializePropertyFiles() {
		initFile();
	}

	@Test
	public void testCase() {
		openBrowser("browser");
		click("Users_linkText");// click on users tab
		click("New_User_linkText");// click on new user link
		getelement("Username_id").sendKeys(username);
		getelement("Password_id").sendKeys(password);
		getelement("Email_id").sendKeys(email);
		click("Create_User_name");//create user button
		Assert.assertEquals(username,getelement("usercreated_id").getText());
	}

	@AfterTest()
	private void closeBrowser() {
		Close();
	}
}
