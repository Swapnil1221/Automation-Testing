/**********
 * 
 * @author Swapnil.Melshankare
 * Test case for creating duplicate user.
 */
package com.mes.test;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class testDuplicateRegister extends testBase {
	String message;
	String username = "Swapnil1221";
	String password = "test@123";
	String email = "Swapnil.melshankare@opusconsulting.com";
	String expectedResult = "New User";

	@BeforeTest
	private void initializePropertyFiles() {
		initFile();
	}

	@Test
	public void testCase() {
		openBrowser("browser");
		click("Users_linkText");// click on users tab
		click("New_User_linkText");// click on new user link
		getelement("Username_id").sendKeys(username);
		getelement("Password_id").sendKeys(password);
		getelement("Email_id").sendKeys(email);
		click("Create_User_name");// create user button
		Assert.assertEquals(getelement("usercreated_id").getText(),expectedResult);
	}

	@AfterTest()
	private void closeBrowser() {
		Close();
	}

}
