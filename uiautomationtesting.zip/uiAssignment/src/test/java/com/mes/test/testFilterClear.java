package com.mes.test;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class testFilterClear extends testBase {
	String numberOfUsers;
	String username = "Swapnil1221";
	String email = "Swapnil.melshankare@opusconsulting.com";

	@BeforeTest
	private void initializePropertyFiles() {
		initFile();
	}

	@Test
	public void testCase() {
		openBrowser("browser");
		click("Users_linkText");
		getelement("userdropdown_xpath").sendKeys("Equals");
		getelement("usernamefilter_id").sendKeys(username);
		getelement("emaildropdown_xpath").sendKeys("Equals");
		getelement("emailfilter_id").sendKeys(email);
		click("clearbutton_xpath");
		Assert.assertEquals((getelement("usernamefilter_id").getText().isEmpty() && getelement("emailfilter_id").getText().isEmpty()), true);

		// click on users tab
		try {
			driver.get("http://ec2-54-84-52-184.compute-1.amazonaws.com:8080/admin/");
			driver.findElement(By.linkText("Users")).click();
			driver.findElement(By.xpath("//div[@id='q_username_input']//select")).sendKeys("Equals");
			driver.findElement(By.id("q_username")).sendKeys(username);
			driver.findElement(By.xpath("//div[@id='q_email_input']//select")).sendKeys("Equals");
			driver.findElement(By.id("q_email")).sendKeys(email);
			driver.findElement(By.className("clear_filters_btn")).click();
			if ((driver.findElement(By.id("q_username")).getText()).isEmpty()
					&& ((driver.findElement(By.id("q_email")).getText()).isEmpty()))
				System.out.println("Success");
			else
				System.out.println("Failure");

			// driver.close();

			// driver.quit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
