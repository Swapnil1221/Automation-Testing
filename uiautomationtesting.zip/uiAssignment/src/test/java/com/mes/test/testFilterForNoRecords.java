/**********
 * 
 * @author Swapnil.Melshankare
 * Test case for retrieving records using filters.
 */
package com.mes.test;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class testFilterForNoRecords extends testBase {
	String numberOfUsers;
	String username = "Swapnil1221";
	String email = "x@gmail.com";
	String expectedResult = "No Users found";

	@BeforeTest
	private void initializePropertyFiles() {
		initFile();
	}

	@Test
	public void testCase() {
		openBrowser("browser");
		click("Users_linkText");// click on users tab
		getelement("userdropdown_xpath").sendKeys("Equals");
		getelement("usernamefilter_id").sendKeys(username);
		getelement("emaildropdown_xpath").sendKeys("Equals");
		getelement("emailfilter_id").sendKeys(email);
		getelement("fromdate_id").sendKeys("2019-02-25");
		getelement("todate_id").sendKeys("2019-03-01");
		click("pageclick_id");
		click("filterbutton_name");
		Assert.assertEquals(getelement("nousers_xpath").getText(), expectedResult);
	}

	@AfterTest()
	private void closeBrowser() {
		Close();
	}
}
